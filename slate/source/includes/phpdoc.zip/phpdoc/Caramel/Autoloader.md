<div class="section class">
    <h2 id="caramel-autoloader" class="class-heading">
        Autoloader
    </h2>
        <div class="class-namespace">
        <small>Caramel\Autoloader</small>
    </div>
        <div class="description-heading">
        Description
    </div>
    <p class="class-description">
        Class Autoloader
compatible to the psr-4 standard

        
    </p>

    
        
        <ul>
                                            </ul>
    
    
        
    
    
    
    
        
    
            
    
                        
                                
    
    
    
                
    
            <div class="methods">
            <h3 id="methods" class="methods-heading">
                Methods
            </h3>


                            <div class="method">
                    <h4 id="__construct" class="sup-heading">
                        __construct
                    </h4>

                    <div class="method-signature">
                        mixed Caramel\Autoloader::__construct(string $dir, string $namespace)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h5 id="__construct-description" class="sub-heading">
                                Description
                            </h5>
                        </div>
                        <div class="sub-description">
                            Autoloader constructor.


                        </div>
                    

                                            <div class="method-arguments">
                            <h5 id="__construct-arguments" class="sub-heading">
                                Arguments
                            </h5>
                        </div>
                        <ul>
                            
                                <li>
                                    string                                    <b>$dir</b>
                                                                    </li>


                            
                                <li>
                                    string                                    <b>$namespace</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h4 id="load" class="sup-heading">
                        load
                    </h4>

                    <div class="method-signature">
                        mixed Caramel\Autoloader::load()
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h5 id="load-description" class="sub-heading">
                                Description
                            </h5>
                        </div>
                        <div class="sub-description">
                            loads the classes


                        </div>
                    

                                    </div>
                    </div>
    </div>