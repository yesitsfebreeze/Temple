<div class="section class">
    <h3 id="caramel-models-vars" class="class-heading">
        Vars
    </h3>
        <div class="class-namespace">
        <small>Caramel\Models\Vars</small>
    </div>
        <div class="description-heading">
        Description
    </div>
    <p class="class-description">
        Class Vars

        
    </p>

    
        
        <ul>
                                        <li>
                    Parent class: Caramel\Models\Storage
                </li>
                                </ul>
    
    
        
    
    
    
    
        
    
            
    
                        
                                
    
    
    
                
    
            <div class="methods">
            <h4 id="methods" class="methods-heading">
                Methods
            </h4>


                            <div class="method">
                    <h5 id="set" class="sup-heading">
                        set
                    </h5>

                    <div class="method-signature">
                        boolean Caramel\Models\Storage::set($path, $value)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Models\Storage</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="set-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="set-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$path</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$value</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="get" class="sup-heading">
                        get
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Models\Storage::get(string $path)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Models\Storage</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="get-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            returns a value from the storage


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="get-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    string                                    <b>$path</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="merge" class="sup-heading">
                        merge
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Models\Storage::merge(array $array)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Models\Storage</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="merge-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            merge an array into the storage


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="merge-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    array                                    <b>$array</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="extend" class="sup-heading">
                        extend
                    </h5>

                    <div class="method-signature">
                        array Caramel\Models\Storage::extend(string $path, array|string $value)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Models\Storage</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="extend-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            extends an array in the storage


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="extend-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    string                                    <b>$path</b>
                                                                    </li>


                            
                                <li>
                                    array|string                                    <b>$value</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="has" class="sup-heading">
                        has
                    </h5>

                    <div class="method-signature">
                        array Caramel\Models\Storage::has(string $path)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Models\Storage</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="has-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            returns if the storage has the passed value


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="has-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    string                                    <b>$path</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="delete" class="sup-heading">
                        delete
                    </h5>

                    <div class="method-signature">
                        boolean Caramel\Models\Storage::delete($path)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Models\Storage</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="delete-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="delete-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$path</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="find" class="sup-heading">
                        find
                    </h5>

                    <div class="method-signature">
                        array Caramel\Models\Storage::find(array|string $attrs, string $value, \Caramel\Models\Storage $item)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Models\Storage</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="find-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            searches for an item in the current tree
if we pass an array it has the same behaviour
iterates over the array values recursively


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="find-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    array|string                                    <b>$attrs</b>
                                                                    </li>


                            
                                <li>
                                    string                                    <b>$value</b>
                                                                    </li>


                            
                                <li>
                                    \Caramel\Models\Storage                                    <b>$item</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="findhelper" class="sup-heading">
                        findHelper
                    </h5>

                    <div class="method-signature">
                        array Caramel\Models\Storage::findHelper(array $found, \Caramel\Models\Storage $item, array|string $attrs, string $value)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Models\Storage</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="findhelper-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            outsourcing the repeating find process


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="findhelper-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    array                                    <b>$found</b>
                                                                    </li>


                            
                                <li>
                                    \Caramel\Models\Storage                                    <b>$item</b>
                                                                    </li>


                            
                                <li>
                                    array|string                                    <b>$attrs</b>
                                                                    </li>


                            
                                <li>
                                    string                                    <b>$value</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="getter" class="sup-heading">
                        getter
                    </h5>

                    <div class="method-signature">
                        array Caramel\Models\Storage::getter($path)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Models\Storage</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="getter-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            the method to set data


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="getter-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$path</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setter" class="sup-heading">
                        setter
                    </h5>

                    <div class="method-signature">
                        boolean Caramel\Models\Storage::setter($path, $value)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Models\Storage</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setter-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setter-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$path</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$value</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="createpath" class="sup-heading">
                        createPath
                    </h5>

                    <div class="method-signature">
                        array|mixed Caramel\Models\Storage::createPath($path)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Models\Storage</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="createpath-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            returns the path as an array


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="createpath-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$path</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                    </div>
    </div>