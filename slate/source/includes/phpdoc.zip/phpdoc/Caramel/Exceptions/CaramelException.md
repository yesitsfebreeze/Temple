<div class="section class">
    <h3 id="caramel-exceptions-caramelexception" class="class-heading">
        CaramelException
    </h3>
        <div class="class-namespace">
        <small>Caramel\Exceptions\CaramelException</small>
    </div>
        <div class="description-heading">
        Description
    </div>
    <p class="class-description">
        Class CaramelException

        
    </p>

    
        
        <ul>
                                        <li>
                    Parent class: Exception
                </li>
                                </ul>
    
    
        
    
    
    
    
        
    
            
    
                        
                                
    
    
    
                
    
            <div class="methods">
            <h4 id="methods" class="methods-heading">
                Methods
            </h4>


                            <div class="method">
                    <h5 id="__construct" class="sup-heading">
                        __construct
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Exceptions\CaramelException::__construct($message, $file, $line, $code, \Exception $previous)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="__construct-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="__construct-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$message</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$file</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$line</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$code</b>
                                                                    </li>


                            
                                <li>
                                    \Exception                                    <b>$previous</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="getcaramelfile" class="sup-heading">
                        getCaramelFile
                    </h5>

                    <div class="method-signature">
                        boolean|string Caramel\Exceptions\CaramelException::getCaramelFile()
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="getcaramelfile-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            returns the caramel file


                        </div>
                    

                                    </div>
                            <div class="method">
                    <h5 id="getcaramelline" class="sup-heading">
                        getCaramelLine
                    </h5>

                    <div class="method-signature">
                        boolean|integer|string Caramel\Exceptions\CaramelException::getCaramelLine()
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="getcaramelline-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            returns the caramel line


                        </div>
                    

                                    </div>
                            <div class="method">
                    <h5 id="splitfile" class="sup-heading">
                        splitFile
                    </h5>

                    <div class="method-signature">
                        array Caramel\Exceptions\CaramelException::splitFile($file, $root)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="splitfile-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            splits file into name and path


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="splitfile-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$file</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$root</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="displaycaramelerrorfile" class="sup-heading">
                        displayCaramelErrorFile
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Exceptions\CaramelException::displayCaramelErrorFile($root, $file, $line, $function)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="displaycaramelerrorfile-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            displays an exception file


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="displaycaramelerrorfile-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$root</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$file</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$line</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$function</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                    </div>
    </div>