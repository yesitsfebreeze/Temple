<div class="section class">
    <h3 id="caramel-exceptions-exceptionhandler" class="class-heading">
        ExceptionHandler
    </h3>
        <div class="class-namespace">
        <small>Caramel\Exceptions\ExceptionHandler</small>
    </div>
        <div class="description-heading">
        Description
    </div>
    <p class="class-description">
        Class ExceptionHandler

        
    </p>

    
        
        <ul>
                                            </ul>
    
    
        
    
    
    
    
        
    
            
    
                        
                                
    
    
    
                
    
            <div class="methods">
            <h4 id="methods" class="methods-heading">
                Methods
            </h4>


                            <div class="method">
                    <h5 id="__construct" class="sup-heading">
                        __construct
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Exceptions\ExceptionHandler::__construct()
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="__construct-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            adds a global exception handler for caramel exceptions
ExceptionHandler constructor.


                        </div>
                    

                                    </div>
                    </div>
    </div>