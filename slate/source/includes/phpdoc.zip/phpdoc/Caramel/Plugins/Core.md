<h3 id="caramel/plugins/core">
    Core
</h3>