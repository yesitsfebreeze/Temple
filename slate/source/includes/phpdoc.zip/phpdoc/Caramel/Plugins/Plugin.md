<div class="section class">
    <h3 id="caramel-plugins-plugin" class="class-heading">
        Plugin
    </h3>
        <div class="class-namespace">
        <small>Caramel\Plugins\Plugin</small>
    </div>
        <div class="description-heading">
        Description
    </div>
    <p class="class-description">
        Class Plugins

        
    </p>

    
        
        <ul>
                            <li>
                    This is an <b>abstract</b> class
                </li>
                                        <li>
                    Parent class: Caramel\Services\Service
                </li>
                                </ul>
    
    
        
    
    
    
    
        
    
            
    
                        
                                
    
    
    
                
    
            <div class="methods">
            <h4 id="methods" class="methods-heading">
                Methods
            </h4>


                            <div class="method">
                    <h5 id="position" class="sup-heading">
                        position
                    </h5>

                    <div class="method-signature">
                        integer Caramel\Plugins\Plugin::position()
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                    <li>
                                This method is <b>abstract</b>.
                            </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="position-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                    </div>
                            <div class="method">
                    <h5 id="getname" class="sup-heading">
                        getName
                    </h5>

                    <div class="method-signature">
                        string Caramel\Plugins\Plugin::getName()
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="getname-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                    </div>
                            <div class="method">
                    <h5 id="preprocess" class="sup-heading">
                        preProcess
                    </h5>

                    <div class="method-signature">
                        \Caramel\Models\Dom Caramel\Plugins\Plugin::preProcess(\Caramel\Models\Dom $dom)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="preprocess-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            this is called before we even touch a node
so we can add stuff to our config etc


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="preprocess-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Dom                                    <b>$dom</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="process" class="sup-heading">
                        process
                    </h5>

                    <div class="method-signature">
                        \Caramel\Models\Node Caramel\Plugins\Plugin::process(\Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="process-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            the function we should use for processing a node


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="process-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="check" class="sup-heading">
                        check
                    </h5>

                    <div class="method-signature">
                        boolean Caramel\Plugins\Plugin::check($node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="check-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            the function to check if we want to
modify a node


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="check-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="realprocess" class="sup-heading">
                        realProcess
                    </h5>

                    <div class="method-signature">
                        \Caramel\Models\Node Caramel\Plugins\Plugin::realProcess(\Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="realprocess-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            processes the actual node
if all requirements are met


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="realprocess-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="postprocess" class="sup-heading">
                        postProcess
                    </h5>

                    <div class="method-signature">
                        \Caramel\Models\Dom Caramel\Plugins\Plugin::postProcess(\Caramel\Models\Dom $dom)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="postprocess-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            this is called after the plugins processed
all nodes


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="postprocess-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Dom                                    <b>$dom</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="processoutput" class="sup-heading">
                        processOutput
                    </h5>

                    <div class="method-signature">
                        string Caramel\Plugins\Plugin::processOutput($output)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="processoutput-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            this is called after the plugins processed
all nodes and converted it into a html string


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="processoutput-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$output</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setcaramel" class="sup-heading">
                        setCaramel
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setCaramel(\Caramel\Caramel $Caramel)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setcaramel-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->caramel


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setcaramel-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Caramel                                    <b>$Caramel</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setyaml" class="sup-heading">
                        setYaml
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setYaml(\Symfony\Component\Yaml\Yaml $Yaml)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setyaml-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->yaml


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setyaml-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Symfony\Component\Yaml\Yaml                                    <b>$Yaml</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setvars" class="sup-heading">
                        setVars
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setVars(\Caramel\Models\Vars $Vars)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setvars-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->vars


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setvars-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Vars                                    <b>$Vars</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setconfig" class="sup-heading">
                        setConfig
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setConfig(\Caramel\Services\Config $Config)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setconfig-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->config


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setconfig-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Config                                    <b>$Config</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setdirectories" class="sup-heading">
                        setDirectories
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setDirectories(\Caramel\Services\Directories $Directories)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setdirectories-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->directories


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setdirectories-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Directories                                    <b>$Directories</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="sethelpers" class="sup-heading">
                        setHelpers
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setHelpers(\Caramel\Services\Helpers $Helpers)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="sethelpers-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->helpers


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="sethelpers-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Helpers                                    <b>$Helpers</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setcache" class="sup-heading">
                        setCache
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setCache(\Caramel\Services\Cache $Cache)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setcache-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->cache


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setcache-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Cache                                    <b>$Cache</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setplugins" class="sup-heading">
                        setPlugins
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setPlugins(\Caramel\Services\Plugins $Plugins)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setplugins-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->plugins


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setplugins-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Plugins                                    <b>$Plugins</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setlexer" class="sup-heading">
                        setLexer
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setLexer(\Caramel\Services\Lexer $Lexer)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setlexer-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->lexer


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setlexer-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Lexer                                    <b>$Lexer</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setparser" class="sup-heading">
                        setParser
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setParser(\Caramel\Services\Parser $Parser)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setparser-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->parser


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setparser-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Parser                                    <b>$Parser</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="settemplate" class="sup-heading">
                        setTemplate
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setTemplate(\Caramel\Services\Template $Template)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="settemplate-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->template


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="settemplate-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Template                                    <b>$Template</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                    </div>
    </div>