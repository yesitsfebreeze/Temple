<div class="section class">
    <h4 id="caramel-plugins-core-pluginphp" class="class-heading">
        PluginPhp
    </h4>
        <div class="class-namespace">
        <small>Caramel\Plugins\Core\PluginPhp</small>
    </div>
        <div class="description-heading">
        Description
    </div>
    <p class="class-description">
        Class PluginPhp

        
    </p>

    
        
        <ul>
                                        <li>
                    Parent class: phpDocumentor\Plugin\Plugin
                </li>
                                </ul>
    
    
        
    
    
    
    
        
    
            
    
                        
                                
    
    
    
                
    
            <div class="methods">
            <h5 id="methods" class="methods-heading">
                Methods
            </h5>


                            <div class="method">
                    <h6 id="position" class="sup-heading">
                        position
                    </h6>

                    <div class="method-signature">
                        \Caramel\Plugins\Core\int; Caramel\Plugins\Core\PluginPhp::position()
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="position-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                    </div>
                            <div class="method">
                    <h6 id="check" class="sup-heading">
                        check
                    </h6>

                    <div class="method-signature">
                        boolean Caramel\Plugins\Core\PluginPhp::check(\Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="check-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="check-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h6 id="process" class="sup-heading">
                        process
                    </h6>

                    <div class="method-signature">
                        \Caramel\Models\Node Caramel\Plugins\Core\PluginPhp::process(\Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="process-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="process-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h6 id="processchildren" class="sup-heading">
                        processChildren
                    </h6>

                    <div class="method-signature">
                        \Caramel\Models\Node Caramel\Plugins\Core\PluginPhp::processChildren(\Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="processchildren-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="processchildren-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                    </div>
    </div>