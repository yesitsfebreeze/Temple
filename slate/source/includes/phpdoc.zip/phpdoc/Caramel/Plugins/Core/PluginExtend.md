<div class="section class">
    <h4 id="caramel-plugins-core-pluginextend" class="class-heading">
        PluginExtend
    </h4>
        <div class="class-namespace">
        <small>Caramel\Plugins\Core\PluginExtend</small>
    </div>
        <div class="description-heading">
        Description
    </div>
    <p class="class-description">
        Class PluginExtend

        
    </p>

    
        
        <ul>
                                        <li>
                    Parent class: phpDocumentor\Plugin\Plugin
                </li>
                                </ul>
    
    
        
    
    
    
    
        
    
            
    
                        
                                
    
    
    
                
    
            <div class="methods">
            <h5 id="methods" class="methods-heading">
                Methods
            </h5>


                            <div class="method">
                    <h6 id="position" class="sup-heading">
                        position
                    </h6>

                    <div class="method-signature">
                        \Caramel\Plugins\Core\int; Caramel\Plugins\Core\PluginExtend::position()
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="position-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                    </div>
                            <div class="method">
                    <h6 id="check" class="sup-heading">
                        check
                    </h6>

                    <div class="method-signature">
                        boolean Caramel\Plugins\Core\PluginExtend::check(\Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="check-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="check-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h6 id="process" class="sup-heading">
                        process
                    </h6>

                    <div class="method-signature">
                        \Caramel\Models\Node Caramel\Plugins\Core\PluginExtend::process(\Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="process-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            converts the blocks to comments or completely removes them
depending on configuration


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="process-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h6 id="preprocess" class="sup-heading">
                        preProcess
                    </h6>

                    <div class="method-signature">
                        array Caramel\Plugins\Core\PluginExtend::preProcess(\Caramel\Models\Dom $dom)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="preprocess-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            handles the extending of templates


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="preprocess-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Dom                                    <b>$dom</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h6 id="extending" class="sup-heading">
                        extending
                    </h6>

                    <div class="method-signature">
                        boolean|mixed Caramel\Plugins\Core\PluginExtend::extending(\Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="extending-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            checks if the file has an valid extend tag


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="extending-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h6 id="extend" class="sup-heading">
                        extend
                    </h6>

                    <div class="method-signature">
                        array Caramel\Plugins\Core\PluginExtend::extend(\Caramel\Models\Dom $dom, \Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="extend-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            extends the current file and replaces all blocks
this will restart the parsing process


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="extend-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Dom                                    <b>$dom</b>
                                                                    </li>


                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h6 id="getrootfile" class="sup-heading">
                        getRootFile
                    </h6>

                    <div class="method-signature">
                        mixed Caramel\Plugins\Core\PluginExtend::getRootFile(\Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>protected</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="getrootfile-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="getrootfile-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h6 id="getblocks" class="sup-heading">
                        getBlocks
                    </h6>

                    <div class="method-signature">
                        array Caramel\Plugins\Core\PluginExtend::getBlocks(\Caramel\Models\Dom $dom)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="getblocks-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            get all extending blocks from our current dom


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="getblocks-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Dom                                    <b>$dom</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h6 id="getdom" class="sup-heading">
                        getDom
                    </h6>

                    <div class="method-signature">
                        \Caramel\Models\Dom Caramel\Plugins\Core\PluginExtend::getDom(\Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="getdom-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            returns the dom of the file which got extended


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="getdom-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h6 id="blocks" class="sup-heading">
                        blocks
                    </h6>

                    <div class="method-signature">
                        mixed Caramel\Plugins\Core\PluginExtend::blocks(\Caramel\Models\Dom $dom, array $blocks)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="blocks-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            extend all blocks in the current dom


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="blocks-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Dom                                    <b>$dom</b>
                                                                    </li>


                            
                                <li>
                                    array                                    <b>$blocks</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h6 id="block" class="sup-heading">
                        block
                    </h6>

                    <div class="method-signature">
                        \Caramel\Models\Node Caramel\Plugins\Core\PluginExtend::block(\Caramel\Models\Node $node, \Caramel\Models\Node $block)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="block-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            inserts the node into "block parent" if available
and then replaces the node with the block


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="block-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$block</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h6 id="parent" class="sup-heading">
                        parent
                    </h6>

                    <div class="method-signature">
                        mixed Caramel\Plugins\Core\PluginExtend::parent(\Caramel\Models\Node $node, \Caramel\Models\Node $block)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="parent-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="parent-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$block</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                    </div>
    </div>