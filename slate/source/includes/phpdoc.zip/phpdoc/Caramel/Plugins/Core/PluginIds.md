<div class="section class">
    <h4 id="caramel-plugins-core-pluginids" class="class-heading">
        PluginIds
    </h4>
        <div class="class-namespace">
        <small>Caramel\Plugins\Core\PluginIds</small>
    </div>
        <div class="description-heading">
        Description
    </div>
    <p class="class-description">
        Class PluginIds

        
    </p>

    
        
        <ul>
                                        <li>
                    Parent class: phpDocumentor\Plugin\Plugin
                </li>
                                </ul>
    
    
        
    
    
    
    
        
    
            
    
                        
                                
    
    
    
                
    
            <div class="methods">
            <h5 id="methods" class="methods-heading">
                Methods
            </h5>


                            <div class="method">
                    <h6 id="position" class="sup-heading">
                        position
                    </h6>

                    <div class="method-signature">
                        \Caramel\Plugins\Core\int; Caramel\Plugins\Core\PluginIds::position()
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="position-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                    </div>
                            <div class="method">
                    <h6 id="process" class="sup-heading">
                        process
                    </h6>

                    <div class="method-signature">
                        \Caramel\Models\Node Caramel\Plugins\Core\PluginIds::process(\Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="process-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="process-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h6 id="getids" class="sup-heading">
                        getIds
                    </h6>

                    <div class="method-signature">
                        string Caramel\Plugins\Core\PluginIds::getIds(string $tag, array $ids)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="getids-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="getids-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    string                                    <b>$tag</b>
                                                                    </li>


                            
                                <li>
                                    array                                    <b>$ids</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h6 id="updatetag" class="sup-heading">
                        updateTag
                    </h6>

                    <div class="method-signature">
                        mixed Caramel\Plugins\Core\PluginIds::updateTag(\Caramel\Models\Node $node, string $tag, array $ids)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="updatetag-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="updatetag-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                            
                                <li>
                                    string                                    <b>$tag</b>
                                                                    </li>


                            
                                <li>
                                    array                                    <b>$ids</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h6 id="setattribute" class="sup-heading">
                        setAttribute
                    </h6>

                    <div class="method-signature">
                        \Caramel\Models\Node Caramel\Plugins\Core\PluginIds::setAttribute(\Caramel\Models\Node $node, array $ids)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="setattribute-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="setattribute-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                            
                                <li>
                                    array                                    <b>$ids</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h6 id="createnewtag" class="sup-heading">
                        createNewTag
                    </h6>

                    <div class="method-signature">
                        string Caramel\Plugins\Core\PluginIds::createNewTag(\Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h7 id="createnewtag-description" class="sub-heading">
                                Description
                            </h7>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h7 id="createnewtag-arguments" class="sub-heading">
                                Arguments
                            </h7>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                    </div>
    </div>