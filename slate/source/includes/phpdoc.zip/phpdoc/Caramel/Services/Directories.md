<div class="section class">
    <h3 id="caramel-services-directories" class="class-heading">
        Directories
    </h3>
        <div class="class-namespace">
        <small>Caramel\Services\Directories</small>
    </div>
        <div class="description-heading">
        Description
    </div>
    <p class="class-description">
        handles the directory creation
Class Directories

        
    </p>

    
        
        <ul>
                                        <li>
                    Parent class: Caramel\Services\Service
                </li>
                                </ul>
    
    
        
    
    
    
    
        
    
            
    
                        
                                
    
    
    
                
    
            <div class="methods">
            <h4 id="methods" class="methods-heading">
                Methods
            </h4>


                            <div class="method">
                    <h5 id="add" class="sup-heading">
                        add
                    </h5>

                    <div class="method-signature">
                        boolean Caramel\Services\Directories::add(string $dir, string $name, boolean $create)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="add-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            validates and adds a directory to our config
the $name variable will determent the array name
the $single variable will create a simple string instead of an array
note: the directories will be added top down,
so the last added item will be indexed with 0


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="add-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    string                                    <b>$dir</b>
                                                                    </li>


                            
                                <li>
                                    string                                    <b>$name</b>
                                                                    </li>


                            
                                <li>
                                    boolean                                    <b>$create</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="get" class="sup-heading">
                        get
                    </h5>

                    <div class="method-signature">
                        array|boolean Caramel\Services\Directories::get($name)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="get-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            returns the selected directory/ies


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="get-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$name</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="remove" class="sup-heading">
                        remove
                    </h5>

                    <div class="method-signature">
                        boolean Caramel\Services\Directories::remove(integer $pos, string $name)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="remove-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="remove-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    integer                                    <b>$pos</b>
                                                                    </li>


                            
                                <li>
                                    string                                    <b>$name</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="forarray" class="sup-heading">
                        forArray
                    </h5>

                    <div class="method-signature">
                        boolean|string Caramel\Services\Directories::forArray($name, $dirs, $dir, $create)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="forarray-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="forarray-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$name</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$dirs</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$dir</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$create</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="forstring" class="sup-heading">
                        forString
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Directories::forString($name, $dirs, $dir, $create)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="forstring-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="forstring-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$name</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$dirs</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$dir</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$create</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="create" class="sup-heading">
                        create
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Directories::create(boolean $create, string $dir)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="create-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="create-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    boolean                                    <b>$create</b>
                                                                    </li>


                            
                                <li>
                                    string                                    <b>$dir</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="path" class="sup-heading">
                        path
                    </h5>

                    <div class="method-signature">
                        string Caramel\Services\Directories::path($dir)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="path-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            checks if we have a relative or an absolute directory
and returns the adjusted directory


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="path-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$dir</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="validate" class="sup-heading">
                        validate
                    </h5>

                    <div class="method-signature">
                        string Caramel\Services\Directories::validate($dir)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="validate-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            checks if the passed directory exists


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="validate-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$dir</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="root" class="sup-heading">
                        root
                    </h5>

                    <div class="method-signature">
                        string Caramel\Services\Directories::root()
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="root-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            gets the current document root


                        </div>
                    

                                    </div>
                            <div class="method">
                    <h5 id="framework" class="sup-heading">
                        framework
                    </h5>

                    <div class="method-signature">
                        array|string Caramel\Services\Directories::framework()
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="framework-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            Returns the Caramel Directory


                        </div>
                    

                                    </div>
                            <div class="method">
                    <h5 id="setcaramel" class="sup-heading">
                        setCaramel
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setCaramel(\Caramel\Caramel $Caramel)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setcaramel-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->caramel


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setcaramel-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Caramel                                    <b>$Caramel</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setyaml" class="sup-heading">
                        setYaml
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setYaml(\Symfony\Component\Yaml\Yaml $Yaml)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setyaml-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->yaml


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setyaml-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Symfony\Component\Yaml\Yaml                                    <b>$Yaml</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setvars" class="sup-heading">
                        setVars
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setVars(\Caramel\Models\Vars $Vars)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setvars-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->vars


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setvars-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Vars                                    <b>$Vars</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setconfig" class="sup-heading">
                        setConfig
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setConfig(\Caramel\Services\Config $Config)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setconfig-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->config


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setconfig-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Config                                    <b>$Config</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setdirectories" class="sup-heading">
                        setDirectories
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setDirectories(\Caramel\Services\Directories $Directories)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setdirectories-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->directories


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setdirectories-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Directories                                    <b>$Directories</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="sethelpers" class="sup-heading">
                        setHelpers
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setHelpers(\Caramel\Services\Helpers $Helpers)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="sethelpers-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->helpers


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="sethelpers-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Helpers                                    <b>$Helpers</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setcache" class="sup-heading">
                        setCache
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setCache(\Caramel\Services\Cache $Cache)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setcache-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->cache


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setcache-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Cache                                    <b>$Cache</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setplugins" class="sup-heading">
                        setPlugins
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setPlugins(\Caramel\Services\Plugins $Plugins)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setplugins-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->plugins


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setplugins-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Plugins                                    <b>$Plugins</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setlexer" class="sup-heading">
                        setLexer
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setLexer(\Caramel\Services\Lexer $Lexer)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setlexer-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->lexer


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setlexer-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Lexer                                    <b>$Lexer</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setparser" class="sup-heading">
                        setParser
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setParser(\Caramel\Services\Parser $Parser)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setparser-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->parser


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setparser-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Parser                                    <b>$Parser</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="settemplate" class="sup-heading">
                        setTemplate
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setTemplate(\Caramel\Services\Template $Template)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="settemplate-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->template


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="settemplate-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Template                                    <b>$Template</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                    </div>
    </div>