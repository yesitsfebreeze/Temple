<div class="section class">
    <h3 id="caramel-services-parser" class="class-heading">
        Parser
    </h3>
        <div class="class-namespace">
        <small>Caramel\Services\Parser</small>
    </div>
        <div class="description-heading">
        Description
    </div>
    <p class="class-description">
        Class Parser

        
    </p>

    
        
        <ul>
                                        <li>
                    Parent class: Caramel\Services\Service
                </li>
                                </ul>
    
    
        
    
    
    
    
        
    
            
    
                        
                                
    
    
    
                
    
            <div class="methods">
            <h4 id="methods" class="methods-heading">
                Methods
            </h4>


                            <div class="method">
                    <h5 id="parse" class="sup-heading">
                        parse
                    </h5>

                    <div class="method-signature">
                        boolean Caramel\Services\Parser::parse(\Caramel\Models\Dom $dom)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="parse-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="parse-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Dom                                    <b>$dom</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="check" class="sup-heading">
                        check
                    </h5>

                    <div class="method-signature">
                        boolean Caramel\Services\Parser::check(\Caramel\Models\Dom $dom)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="check-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            checks if we have a valid dom object


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="check-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Dom                                    <b>$dom</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="output" class="sup-heading">
                        output
                    </h5>

                    <div class="method-signature">
                        string Caramel\Services\Parser::output(\Caramel\Models\Dom|mixed $dom)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="output-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            merges the nodes to a string


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="output-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Dom|mixed                                    <b>$dom</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="preprocessplugins" class="sup-heading">
                        preProcessPlugins
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Parser::preProcessPlugins(\Caramel\Models\Dom $dom)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="preprocessplugins-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            execute the plugins before we do anything else


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="preprocessplugins-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Dom                                    <b>$dom</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="processplugins" class="sup-heading">
                        processPlugins
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Parser::processPlugins(\Caramel\Models\Dom|array $dom, array $nodes)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="processplugins-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            execute the plugins on each individual node
children will parsed first


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="processplugins-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Dom|array                                    <b>$dom</b>
                                                                    </li>


                            
                                <li>
                                    array                                    <b>$nodes</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="postprocessplugins" class="sup-heading">
                        postProcessPlugins
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Parser::postProcessPlugins(\Caramel\Models\Dom $dom)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="postprocessplugins-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            process the plugins after the main plugin process


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="postprocessplugins-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Dom                                    <b>$dom</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="processoutputplugins" class="sup-heading">
                        processOutputPlugins
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Parser::processOutputPlugins(string $output)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="processoutputplugins-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            process the plugins after rendering is complete


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="processoutputplugins-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    string                                    <b>$output</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="executeplugins" class="sup-heading">
                        executePlugins
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Parser::executePlugins(\Caramel\Models\Dom|\Caramel\Models\Node|string $element, string $type)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="executeplugins-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            processes all plugins depending on the passed type


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="executeplugins-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Dom|\Caramel\Models\Node|string                                    <b>$element</b>
                                                                    </li>


                            
                                <li>
                                    string                                    <b>$type</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="pluginerror" class="sup-heading">
                        PluginError
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Parser::PluginError($element, $plugin, $method, $variable)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="pluginerror-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            helper method for plugin return errors


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="pluginerror-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$element</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$plugin</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$method</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$variable</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setcaramel" class="sup-heading">
                        setCaramel
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setCaramel(\Caramel\Caramel $Caramel)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setcaramel-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->caramel


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setcaramel-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Caramel                                    <b>$Caramel</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setyaml" class="sup-heading">
                        setYaml
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setYaml(\Symfony\Component\Yaml\Yaml $Yaml)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setyaml-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->yaml


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setyaml-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Symfony\Component\Yaml\Yaml                                    <b>$Yaml</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setvars" class="sup-heading">
                        setVars
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setVars(\Caramel\Models\Vars $Vars)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setvars-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->vars


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setvars-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Vars                                    <b>$Vars</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setconfig" class="sup-heading">
                        setConfig
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setConfig(\Caramel\Services\Config $Config)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setconfig-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->config


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setconfig-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Config                                    <b>$Config</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setdirectories" class="sup-heading">
                        setDirectories
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setDirectories(\Caramel\Services\Directories $Directories)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setdirectories-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->directories


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setdirectories-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Directories                                    <b>$Directories</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="sethelpers" class="sup-heading">
                        setHelpers
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setHelpers(\Caramel\Services\Helpers $Helpers)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="sethelpers-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->helpers


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="sethelpers-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Helpers                                    <b>$Helpers</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setcache" class="sup-heading">
                        setCache
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setCache(\Caramel\Services\Cache $Cache)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setcache-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->cache


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setcache-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Cache                                    <b>$Cache</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setplugins" class="sup-heading">
                        setPlugins
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setPlugins(\Caramel\Services\Plugins $Plugins)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setplugins-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->plugins


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setplugins-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Plugins                                    <b>$Plugins</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setlexer" class="sup-heading">
                        setLexer
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setLexer(\Caramel\Services\Lexer $Lexer)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setlexer-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->lexer


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setlexer-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Lexer                                    <b>$Lexer</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setparser" class="sup-heading">
                        setParser
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setParser(\Caramel\Services\Parser $Parser)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setparser-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->parser


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setparser-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Parser                                    <b>$Parser</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="settemplate" class="sup-heading">
                        setTemplate
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setTemplate(\Caramel\Services\Template $Template)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="settemplate-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->template


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="settemplate-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Template                                    <b>$Template</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                    </div>
    </div>