<div class="section class">
    <h3 id="caramel-services-lexer" class="class-heading">
        Lexer
    </h3>
        <div class="class-namespace">
        <small>Caramel\Services\Lexer</small>
    </div>
        <div class="description-heading">
        Description
    </div>
    <p class="class-description">
        Class Lexer

        
    </p>

    
        
        <ul>
                                        <li>
                    Parent class: Caramel\Services\Service
                </li>
                                </ul>
    
    
        
    
    
    
    
        
    
            
    
                        
                                
    
    
    
                
    
            <div class="methods">
            <h4 id="methods" class="methods-heading">
                Methods
            </h4>


                            <div class="method">
                    <h5 id="lex" class="sup-heading">
                        lex
                    </h5>

                    <div class="method-signature">
                        array Caramel\Services\Lexer::lex(string $file, integer|boolean $level)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="lex-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            returns Dom object


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="lex-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    string                                    <b>$file</b>
                                                                    </li>


                            
                                <li>
                                    integer|boolean                                    <b>$level</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="prepare" class="sup-heading">
                        prepare
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Lexer::prepare(string $file, integer $level)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="prepare-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            set the default values for our dom


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="prepare-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    string                                    <b>$file</b>
                                                                    </li>


                            
                                <li>
                                    integer                                    <b>$level</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="template" class="sup-heading">
                        template
                    </h5>

                    <div class="method-signature">
                        \Caramel\Models\Storage Caramel\Services\Lexer::template($file, $level)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="template-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            returns the matching file template


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="template-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$file</b>
                                                                    </li>


                            
                                <li>
                                    mixed                                    <b>$level</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="process" class="sup-heading">
                        process
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Lexer::process()
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="process-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            creates a dom for the current file


                        </div>
                    

                                    </div>
                            <div class="method">
                    <h5 id="info" class="sup-heading">
                        info
                    </h5>

                    <div class="method-signature">
                        \Caramel\Models\Storage Caramel\Services\Lexer::info($line)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="info-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            returns an array with information about the current node


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="info-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$line</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="indent" class="sup-heading">
                        indent
                    </h5>

                    <div class="method-signature">
                        float|integer Caramel\Services\Lexer::indent($line)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="indent-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            returns the indent of the current line
also initially sets the indent character and amount


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="indent-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    mixed                                    <b>$line</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="tag" class="sup-heading">
                        tag
                    </h5>

                    <div class="method-signature">
                        string Caramel\Services\Lexer::tag(string $line)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="tag-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            returns the tag for the current line


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="tag-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    string                                    <b>$line</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="attributes" class="sup-heading">
                        attributes
                    </h5>

                    <div class="method-signature">
                        string Caramel\Services\Lexer::attributes(string $line, \Caramel\Models\Storage $info)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="attributes-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            returns the attributes for the current line


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="attributes-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    string                                    <b>$line</b>
                                                                    </li>


                            
                                <li>
                                    \Caramel\Models\Storage                                    <b>$info</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="content" class="sup-heading">
                        content
                    </h5>

                    <div class="method-signature">
                        string Caramel\Services\Lexer::content(string $line, \Caramel\Models\Storage $info)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="content-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            returns the content for the current line


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="content-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    string                                    <b>$line</b>
                                                                    </li>


                            
                                <li>
                                    \Caramel\Models\Storage                                    <b>$info</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="selfclosing" class="sup-heading">
                        selfclosing
                    </h5>

                    <div class="method-signature">
                        string Caramel\Services\Lexer::selfclosing(\Caramel\Models\Storage $info)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="selfclosing-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            returns if the current line has a self closing tag


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="selfclosing-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Storage                                    <b>$info</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="node" class="sup-heading">
                        node
                    </h5>

                    <div class="method-signature">
                        \Caramel\Models\Node Caramel\Services\Lexer::node(string $line, \Caramel\Models\Storage $info)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="node-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            creates a new node from a line


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="node-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    string                                    <b>$line</b>
                                                                    </li>


                            
                                <li>
                                    \Caramel\Models\Storage                                    <b>$info</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="add" class="sup-heading">
                        add
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Lexer::add(\Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="add-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            adds the node to the dom
parent/child logic is handled here


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="add-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="deeper" class="sup-heading">
                        deeper
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Lexer::deeper(\Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="deeper-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            adds a node to the dom if has a deeper level
than the previous node


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="deeper-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="higher" class="sup-heading">
                        higher
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Lexer::higher(\Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="higher-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            adds a node to the dom if has a higher level
than the previous node


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="higher-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="same" class="sup-heading">
                        same
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Lexer::same(\Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="same-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            adds a node to the dom if has the same  level
than the previous node


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="same-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="children" class="sup-heading">
                        children
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Lexer::children(\Caramel\Models\Node $target, \Caramel\Models\Node $node)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="children-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            adds the passed node to children


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="children-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$target</b>
                                                                    </li>


                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="parent" class="sup-heading">
                        parent
                    </h5>

                    <div class="method-signature">
                        \Caramel\Models\Node Caramel\Services\Lexer::parent(\Caramel\Models\Node $node, boolean|\Caramel\Models\Node $parent)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>private</b>
                        </li>
                                                                                            </ul>

                                            <div class="method-description">
                            <h6 id="parent-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            returns the parent of the passed node


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="parent-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Node                                    <b>$node</b>
                                                                    </li>


                            
                                <li>
                                    boolean|\Caramel\Models\Node                                    <b>$parent</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setcaramel" class="sup-heading">
                        setCaramel
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setCaramel(\Caramel\Caramel $Caramel)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setcaramel-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->caramel


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setcaramel-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Caramel                                    <b>$Caramel</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setyaml" class="sup-heading">
                        setYaml
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setYaml(\Symfony\Component\Yaml\Yaml $Yaml)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setyaml-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->yaml


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setyaml-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Symfony\Component\Yaml\Yaml                                    <b>$Yaml</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setvars" class="sup-heading">
                        setVars
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setVars(\Caramel\Models\Vars $Vars)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setvars-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->vars


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setvars-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Models\Vars                                    <b>$Vars</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setconfig" class="sup-heading">
                        setConfig
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setConfig(\Caramel\Services\Config $Config)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setconfig-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->config


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setconfig-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Config                                    <b>$Config</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setdirectories" class="sup-heading">
                        setDirectories
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setDirectories(\Caramel\Services\Directories $Directories)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setdirectories-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->directories


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setdirectories-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Directories                                    <b>$Directories</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="sethelpers" class="sup-heading">
                        setHelpers
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setHelpers(\Caramel\Services\Helpers $Helpers)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="sethelpers-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->helpers


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="sethelpers-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Helpers                                    <b>$Helpers</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setcache" class="sup-heading">
                        setCache
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setCache(\Caramel\Services\Cache $Cache)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setcache-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->cache


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setcache-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Cache                                    <b>$Cache</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setplugins" class="sup-heading">
                        setPlugins
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setPlugins(\Caramel\Services\Plugins $Plugins)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setplugins-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->plugins


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setplugins-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Plugins                                    <b>$Plugins</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setlexer" class="sup-heading">
                        setLexer
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setLexer(\Caramel\Services\Lexer $Lexer)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setlexer-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->lexer


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setlexer-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Lexer                                    <b>$Lexer</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="setparser" class="sup-heading">
                        setParser
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setParser(\Caramel\Services\Parser $Parser)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="setparser-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->parser


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="setparser-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Parser                                    <b>$Parser</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                            <div class="method">
                    <h5 id="settemplate" class="sup-heading">
                        setTemplate
                    </h5>

                    <div class="method-signature">
                        mixed Caramel\Services\Service::setTemplate(\Caramel\Services\Template $Template)
                    </div>

                    
                    <ul>
                        <li>
                            Visibility: <b>public</b>
                        </li>
                                                                                                    <li>
                                This method is defined by: <b>Caramel\Services\Service</b>
                            </li>
                                            </ul>

                                            <div class="method-description">
                            <h6 id="settemplate-description" class="sub-heading">
                                Description
                            </h6>
                        </div>
                        <div class="sub-description">
                            sets $this->template


                        </div>
                    

                                            <div class="method-arguments">
                            <h6 id="settemplate-arguments" class="sub-heading">
                                Arguments
                            </h6>
                        </div>
                        <ul>
                            
                                <li>
                                    \Caramel\Services\Template                                    <b>$Template</b>
                                                                    </li>


                                                    </ul>

                                    </div>
                    </div>
    </div>