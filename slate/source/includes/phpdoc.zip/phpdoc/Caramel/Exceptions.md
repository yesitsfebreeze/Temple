<h2 id="caramel/exceptions">
    Exceptions
</h2>